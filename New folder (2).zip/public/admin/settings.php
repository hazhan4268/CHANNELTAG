<?php
/**
 * Admin Settings Entry Point
 */

// Load autoloader
if (file_exists(__DIR__ . '/../../vendor/autoload.php')) {
    require_once __DIR__ . '/../../vendor/autoload.php';
} else {
    require_once __DIR__ . '/../../src/autoload.php';
}

require_once __DIR__ . '/../../src/Bootstrap.php';
require_once __DIR__ . '/../../src/Config.php';
require_once __DIR__ . '/../../src/Controllers/AuthController.php';
require_once __DIR__ . '/../../src/Controllers/AdminController.php';

use TelegramBot\Bootstrap;
use TelegramBot\Controllers\AuthController;
use TelegramBot\Controllers\AdminController;

try {
    Bootstrap::init();
    
    AuthController::checkAuth();
    $controller = new AdminController();
    $controller->settings();
} catch (\Exception $e) {
    http_response_code(500);
    echo "خطای داخلی: " . htmlspecialchars($e->getMessage()) . "<br>";
    echo "فایل: " . htmlspecialchars($e->getFile()) . "<br>";
    echo "خط: " . $e->getLine() . "<br>";
    echo '<br><a href="/admin/debug.php">صفحه Debug</a>';
}
