<?php
/**
 * Webhook Entry Point
 */

// Load autoloader (Composer or simple)
if (file_exists(__DIR__ . '/../vendor/autoload.php')) {
    require_once __DIR__ . '/../vendor/autoload.php';
} else {
    require_once __DIR__ . '/../src/autoload.php';
}

require_once __DIR__ . '/../src/Bootstrap.php';
require_once __DIR__ . '/../src/Config.php';
require_once __DIR__ . '/../src/Router.php';

use TelegramBot\Bootstrap;
use TelegramBot\Router;

try {
    // Initialize
    Bootstrap::init();
    
    // Route webhook
    Router::routeWebhook();
    
    // 404
    http_response_code(404);
    echo 'Not Found';
} catch (\Exception $e) {
    error_log("Webhook error: " . $e->getMessage());
    http_response_code(500);
    // Don't expose error details in production
    exit;
}
