<?php
/**
 * Test page for debugging installation issues
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<h1>Installation Test</h1>";

echo "<h2>PHP Version</h2>";
echo "PHP " . phpversion() . "<br>";

echo "<h2>Required Extensions</h2>";
$required = ['pdo_mysql', 'curl', 'openssl', 'json', 'mbstring'];
foreach ($required as $ext) {
    $loaded = extension_loaded($ext);
    echo $ext . ": " . ($loaded ? "✓ Loaded" : "✗ Missing") . "<br>";
}

echo "<h2>File Checks</h2>";
$files = [
    __DIR__ . '/../src/Logger.php',
    __DIR__ . '/../src/Config.php',
    __DIR__ . '/../src/Services/Installer.php',
    __DIR__ . '/../sql/schema.sql',
    __DIR__ . '/../sql/seed.sql',
];

foreach ($files as $file) {
    $exists = file_exists($file);
    $readable = $exists && is_readable($file);
    echo basename($file) . ": " . ($exists ? "✓" : "✗") . " " . ($readable ? "Readable" : "Not Readable") . "<br>";
}

echo "<h2>Directory Checks</h2>";
$dirs = [
    __DIR__ . '/../config',
    __DIR__ . '/../logs',
];

foreach ($dirs as $dir) {
    $exists = is_dir($dir);
    $writable = $exists && is_writable($dir);
    echo basename($dir) . ": " . ($exists ? "✓" : "✗") . " " . ($writable ? "Writable" : "Not Writable") . "<br>";
}

echo "<h2>Autoload Test</h2>";
try {
    spl_autoload_register(function ($class) {
        $prefix = 'TelegramBot\\';
        $len = strlen($prefix);
        
        if (strncmp($prefix, $class, $len) !== 0) {
            return;
        }
        
        $relative_class = substr($class, $len);
        $file = __DIR__ . '/../src/' . str_replace('\\', '/', $relative_class) . '.php';
        
        if (file_exists($file)) {
            require $file;
            echo "Loaded: {$class}<br>";
            return true;
        }
        
        echo "Not found: {$file}<br>";
        return false;
    });
    
    require_once __DIR__ . '/../src/Logger.php';
    require_once __DIR__ . '/../src/Config.php';
    require_once __DIR__ . '/../src/Services/Installer.php';
    
    $installer = new \TelegramBot\Services\Installer();
    echo "✓ Installer class loaded successfully<br>";
    
    $extCheck = $installer->checkExtensions();
    echo "Extension check: " . ($extCheck['ok'] ? "✓ OK" : "✗ Missing: " . implode(', ', $extCheck['missing'])) . "<br>";
    
} catch (\Exception $e) {
    echo "✗ Error: " . htmlspecialchars($e->getMessage()) . "<br>";
    echo "File: " . $e->getFile() . "<br>";
    echo "Line: " . $e->getLine() . "<br>";
    echo "<pre>" . $e->getTraceAsString() . "</pre>";
}

