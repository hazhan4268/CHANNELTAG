<?php
/**
 * Installation Wizard - نصب‌کننده ربات تلگرام
 */

// Enable error display for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('log_errors', 1);

// Simple autoloader
spl_autoload_register(function ($class) {
    $prefix = 'TelegramBot\\';
    $len = strlen($prefix);
    
    if (strncmp($prefix, $class, $len) !== 0) {
        return;
    }
    
    $relative_class = substr($class, $len);
    $file = __DIR__ . '/../src/' . str_replace('\\', '/', $relative_class) . '.php';
    
    if (file_exists($file)) {
        require $file;
    }
});

// Load required classes
$files = [
    __DIR__ . '/../src/Logger.php',
    __DIR__ . '/../src/Config.php',
    __DIR__ . '/../src/Services/TelegramClient.php',
    __DIR__ . '/../src/Services/Installer.php',
];

foreach ($files as $file) {
    if (file_exists($file)) {
        require_once $file;
    } else {
        die("فایل موردنیاز پیدا نشد: " . basename($file) . "<br>لطفاً فایل‌ها را بررسی کنید.");
    }
}

use TelegramBot\Services\Installer;
use TelegramBot\Services\TelegramClient;
use TelegramBot\Logger;

try {
    $installer = new Installer();
} catch (\Exception $e) {
    die('خطا در بارگذاری نصب‌کننده: ' . htmlspecialchars($e->getMessage()));
}

// Check if already installed
try {
    if ($installer->isInstalled()) {
        die('نصب قبلاً انجام شده است. برای نصب مجدد، پوشه /install را حذف کنید یا دیتابیس را ریست کنید.');
    }
} catch (\Exception $e) {
    // Continue with installation if check fails
}

$step = $_GET['step'] ?? 1;
$step = (int)$step;
$error = null;
$data = [];
$webhookStatus = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'step2') {
        // Step 2: Database
        $data = [
            'DB_HOST' => $_POST['db_host'] ?? 'localhost',
            'DB_NAME' => $_POST['db_name'] ?? '',
            'DB_USER' => $_POST['db_user'] ?? '',
            'DB_PASS' => $_POST['db_pass'] ?? '',
        ];
        
        if (empty($data['DB_NAME']) || empty($data['DB_USER'])) {
            $error = 'نام پایگاه داده و نام کاربری اجباری هستند';
            $step = 2;
        } else {
            $result = $installer->createTables(
                $data['DB_HOST'],
                $data['DB_NAME'],
                $data['DB_USER'],
                $data['DB_PASS']
            );
            
            if ($result['ok']) {
                // Verify tables were created
                try {
                    $pdo = new \PDO(
                        "mysql:host={$data['DB_HOST']};dbname={$data['DB_NAME']};charset=utf8mb4",
                        $data['DB_USER'],
                        $data['DB_PASS']
                    );
                    $tables = $pdo->query("SHOW TABLES")->fetchAll();
                    $tableNames = array_map(function($row) {
                        return array_values($row)[0];
                    }, $tables);
                    
                    $requiredTables = ['settings', 'channels', 'tags', 'posts', 'admins', 'install_flag'];
                    $missingTables = array_diff($requiredTables, $tableNames);
                    
                    if (!empty($missingTables)) {
                        $error = 'جدول‌های زیر ایجاد نشدند: ' . implode(', ', $missingTables) . '. لطفاً دسترسی‌های دیتابیس را بررسی کنید.';
                        $step = 2;
                    } else {
                        // Write .env.php temporarily
                        $envData = array_merge($data, [
                            'BOT_TOKEN' => '',
                            'WEBHOOK_SLUG' => '',
                            'SECRET_TOKEN' => '',
                            'BASE_URL' => '',
                            'PARSE_MODE' => 'MarkdownV2',
                            'LOCALE' => 'fa',
                            'GLOBAL_ON' => true,
                        ]);
                        $installer->writeEnvFile($envData);
                        require_once __DIR__ . '/../src/Config.php';
                        \TelegramBot\Config::load();
                        
                        $step = 3;
                    }
                } catch (\Exception $e) {
                    $error = 'خطا در بررسی جدول‌ها: ' . htmlspecialchars($e->getMessage());
                    $step = 2;
                }
            } else {
                $error = $result['error'] ?? 'خطا در ایجاد پایگاه داده';
                $step = 2;
            }
        }
    } elseif ($action === 'step3') {
        // Step 3: Admin user
        $adminUsername = $_POST['admin_username'] ?? '';
        $adminEmail = $_POST['admin_email'] ?? '';
        $adminPassword = $_POST['admin_password'] ?? '';
        $adminPasswordConfirm = $_POST['admin_password_confirm'] ?? '';
        
        if (empty($adminUsername) || empty($adminPassword)) {
            $error = 'نام کاربری و رمز عبور اجباری هستند';
            $step = 3;
        } elseif ($adminPassword !== $adminPasswordConfirm) {
            $error = 'رمزهای عبور یکسان نیستند';
            $step = 3;
        } else {
            $result = $installer->createAdmin($adminUsername, $adminEmail, $adminPassword, 'owner');
            
            if ($result['ok']) {
                $step = 4;
            } else {
                $error = $result['error'] ?? 'خطا در ایجاد کاربر مدیر';
                $step = 3;
            }
        }
    } elseif ($action === 'step4') {
        // Step 4: Bot configuration
        $botToken = $_POST['bot_token'] ?? '';
        $baseUrl = $_POST['base_url'] ?? '';
        
        if (empty($botToken) || empty($baseUrl)) {
            $error = 'توکن ربات و آدرس وب‌سایت اجباری هستند';
            $step = 4;
        } else {
            // Generate secrets
            $webhookSlug = Installer::generateRandomString(32);
            $secretToken = Installer::generateRandomString(64);
            
            // Read existing DB config
            require_once __DIR__ . '/../src/Config.php';
            $dbData = [
                'DB_HOST' => \TelegramBot\Config::get('DB_HOST'),
                'DB_NAME' => \TelegramBot\Config::get('DB_NAME'),
                'DB_USER' => \TelegramBot\Config::get('DB_USER'),
                'DB_PASS' => \TelegramBot\Config::get('DB_PASS'),
            ];
            
            // Write complete .env.php
            $envData = array_merge($dbData, [
                'BOT_TOKEN' => $botToken,
                'WEBHOOK_SLUG' => $webhookSlug,
                'SECRET_TOKEN' => $secretToken,
                'BASE_URL' => rtrim($baseUrl, '/'),
                'PARSE_MODE' => $_POST['parse_mode'] ?? 'MarkdownV2',
                'LOCALE' => $_POST['locale'] ?? 'fa',
                'GLOBAL_ON' => true,
            ]);
            
            if ($installer->writeEnvFile($envData)) {
                // Reload config
                \TelegramBot\Config::load();
                
                // Mark as installed
                $installer->markInstalled();
                
                $webhookUrl = rtrim($baseUrl, '/') . "/webhook/{$webhookSlug}";
                
                // Auto-set webhook
                try {
                    $logger = new Logger();
                    $telegram = new TelegramClient($botToken, $logger);
                    $webhookResult = $telegram->setWebhook(
                        $webhookUrl,
                        $secretToken,
                        ['channel_post', 'edited_channel_post']
                    );
                    
                    $webhookStatus = [
                        'success' => isset($webhookResult['ok']) && $webhookResult['ok'],
                        'result' => $webhookResult,
                    ];
                } catch (\Exception $e) {
                    $webhookStatus = [
                        'success' => false,
                        'error' => $e->getMessage(),
                    ];
                }
                
                $step = 5;
                $successData = [
                    'webhook_url' => $webhookUrl,
                    'webhook_slug' => $webhookSlug,
                    'webhook_status' => $webhookStatus,
                ];
            } else {
                $error = 'خطا در نوشتن فایل تنظیمات';
                $step = 4;
            }
        }
    }
}

?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>نصب ربات تلگرام - Installation Wizard</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Segoe UI', Tahoma, 'Tahoma', Arial, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 20px;
            min-height: 100vh;
        }
        .container {
            max-width: 700px;
            margin: 0 auto;
            background: white;
            border-radius: 12px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.2);
            padding: 40px;
            overflow: hidden;
        }
        h1 {
            margin-bottom: 30px;
            color: #333;
            text-align: center;
            font-size: 28px;
            border-bottom: 3px solid #667eea;
            padding-bottom: 15px;
        }
        .step {
            margin-bottom: 30px;
        }
        .step h2 {
            font-size: 20px;
            margin-bottom: 15px;
            color: #555;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .step-number {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            width: 35px;
            height: 35px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
        }
        .step-description {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            border-right: 4px solid #667eea;
            color: #666;
            line-height: 1.8;
        }
        .form-group {
            margin-bottom: 20px;
        }
        label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #333;
        }
        input[type="text"], input[type="password"], input[type="email"], select {
            width: 100%;
            padding: 12px;
            border: 2px solid #ddd;
            border-radius: 6px;
            font-size: 15px;
            transition: border-color 0.3s;
        }
        input:focus, select:focus {
            outline: none;
            border-color: #667eea;
        }
        small {
            display: block;
            margin-top: 5px;
            color: #666;
            font-size: 13px;
        }
        .error {
            background: #fee;
            color: #c00;
            padding: 15px;
            border-radius: 6px;
            margin-bottom: 20px;
            border-right: 4px solid #dc3545;
        }
        .success {
            background: #efe;
            color: #060;
            padding: 15px;
            border-radius: 6px;
            margin-bottom: 20px;
            border-right: 4px solid #28a745;
        }
        .warning {
            background: #fff3cd;
            color: #856404;
            padding: 15px;
            border-radius: 6px;
            margin-bottom: 20px;
            border-right: 4px solid #ffc107;
        }
        button {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            padding: 14px 30px;
            border-radius: 6px;
            cursor: pointer;
            font-size: 16px;
            font-weight: 600;
            transition: transform 0.2s, box-shadow 0.2s;
            width: 100%;
        }
        button:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
        }
        button:active {
            transform: translateY(0);
        }
        .info {
            background: #e7f3ff;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 20px;
            border-right: 4px solid #007bff;
        }
        .info code {
            background: #f0f0f0;
            padding: 3px 8px;
            border-radius: 4px;
            font-family: 'Courier New', monospace;
            word-break: break-all;
        }
        .info strong {
            display: block;
            margin-bottom: 10px;
            color: #007bff;
        }
        .step-indicator {
            display: flex;
            justify-content: space-between;
            margin-bottom: 30px;
            padding: 0 20px;
        }
        .step-indicator .step-item {
            flex: 1;
            text-align: center;
            position: relative;
        }
        .step-indicator .step-item::after {
            content: '';
            position: absolute;
            top: 15px;
            right: 50%;
            width: 100%;
            height: 2px;
            background: #ddd;
            z-index: 0;
        }
        .step-indicator .step-item:last-child::after {
            display: none;
        }
        .step-indicator .step-item .step-circle {
            width: 30px;
            height: 30px;
            border-radius: 50%;
            background: #ddd;
            color: white;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            position: relative;
            z-index: 1;
            font-weight: bold;
        }
        .step-indicator .step-item.active .step-circle {
            background: #667eea;
        }
        .step-indicator .step-item.completed .step-circle {
            background: #28a745;
        }
        .progress-bar {
            height: 4px;
            background: #ddd;
            border-radius: 2px;
            margin-bottom: 30px;
            overflow: hidden;
        }
        .progress-bar-fill {
            height: 100%;
            background: linear-gradient(90deg, #667eea 0%, #764ba2 100%);
            transition: width 0.3s;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>🤖 نصب‌کننده ربات تلگرام</h1>
        
        <div class="progress-bar">
            <div class="progress-bar-fill" style="width: <?= ($step / 5) * 100 ?>%"></div>
        </div>
        
        <div class="step-indicator">
            <div class="step-item <?= $step >= 1 ? 'active' : '' ?> <?= $step > 1 ? 'completed' : '' ?>">
                <div class="step-circle">1</div>
            </div>
            <div class="step-item <?= $step >= 2 ? 'active' : '' ?> <?= $step > 2 ? 'completed' : '' ?>">
                <div class="step-circle">2</div>
            </div>
            <div class="step-item <?= $step >= 3 ? 'active' : '' ?> <?= $step > 3 ? 'completed' : '' ?>">
                <div class="step-circle">3</div>
            </div>
            <div class="step-item <?= $step >= 4 ? 'active' : '' ?> <?= $step > 4 ? 'completed' : '' ?>">
                <div class="step-circle">4</div>
            </div>
            <div class="step-item <?= $step >= 5 ? 'active' : '' ?> <?= $step > 5 ? 'completed' : '' ?>">
                <div class="step-circle">✓</div>
            </div>
        </div>
        
        <?php if ($error): ?>
            <div class="error">❌ <?= htmlspecialchars($error) ?></div>
        <?php endif; ?>
        
        <?php if ($step === 1): ?>
            <!-- Step 1: Check Extensions -->
            <div class="step">
                <h2>
                    <span class="step-number">1</span>
                    بررسی سیستم
                </h2>
                <div class="step-description">
                    <strong>📋 این مرحله چه کاری انجام می‌دهد؟</strong><br>
                    بررسی می‌کند که آیا تمام افزونه‌های PHP موردنیاز نصب شده‌اند یا خیر. برای عملکرد صحیح ربات، نیاز به افزونه‌های زیر داریم:
                    <ul style="margin-top: 10px; padding-right: 20px;">
                        <li><strong>pdo_mysql</strong> - برای اتصال به پایگاه داده MySQL</li>
                        <li><strong>curl</strong> - برای ارتباط با API تلگرام</li>
                        <li><strong>openssl</strong> - برای امنیت و رمزگذاری</li>
                        <li><strong>json</strong> - برای پردازش داده‌های JSON</li>
                        <li><strong>mbstring</strong> - برای پردازش رشته‌های فارسی</li>
                    </ul>
                </div>
                <?php
                $extCheck = $installer->checkExtensions();
                if ($extCheck['ok']):
                ?>
                    <div class="success">
                        ✅ تمام افزونه‌های موردنیاز نصب شده‌اند و سیستم آماده نصب است.
                    </div>
                    <a href="?step=2"><button>مرحله بعد →</button></a>
                <?php else: ?>
                    <div class="error">
                        ❌ افزونه‌های مفقود: <strong><?= htmlspecialchars(implode(', ', $extCheck['missing'])) ?></strong><br><br>
                        لطفاً از ارائه‌دهنده هاستینگ خود بخواهید این افزونه‌ها را نصب کنند.
                    </div>
                <?php endif; ?>
            </div>
            
        <?php elseif ($step === 2): ?>
            <!-- Step 2: Database -->
            <div class="step">
                <h2>
                    <span class="step-number">2</span>
                    پیکربندی پایگاه داده
                </h2>
                <div class="step-description">
                    <strong>📋 این مرحله چه کاری انجام می‌دهد؟</strong><br>
                    اطلاعات اتصال به پایگاه داده MySQL را از شما می‌گیرد و جداول موردنیاز را ایجاد می‌کند. این اطلاعات را می‌توانید از پنل مدیریت هاستینگ خود (cPanel) دریافت کنید.
                </div>
                <form method="POST">
                    <input type="hidden" name="action" value="step2">
                    <div class="form-group">
                        <label>آدرس سرور پایگاه داده:</label>
                        <input type="text" name="db_host" value="<?= htmlspecialchars($data['DB_HOST'] ?? 'localhost') ?>" required>
                        <small>معمولاً "localhost" است. در صورت نیاز از ارائه‌دهنده هاستینگ بپرسید.</small>
                    </div>
                    <div class="form-group">
                        <label>نام پایگاه داده: <span style="color: red;">*</span></label>
                        <input type="text" name="db_name" value="<?= htmlspecialchars($data['DB_NAME'] ?? '') ?>" required>
                        <small>نام پایگاه داده‌ای که در cPanel ایجاد کرده‌اید.</small>
                    </div>
                    <div class="form-group">
                        <label>نام کاربری پایگاه داده: <span style="color: red;">*</span></label>
                        <input type="text" name="db_user" value="<?= htmlspecialchars($data['DB_USER'] ?? '') ?>" required>
                        <small>نام کاربری که برای پایگاه داده ساخته‌اید.</small>
                    </div>
                    <div class="form-group">
                        <label>رمز عبور پایگاه داده:</label>
                        <input type="password" name="db_pass" value="<?= htmlspecialchars($data['DB_PASS'] ?? '') ?>">
                        <small>رمز عبور پایگاه داده (در صورت وجود).</small>
                    </div>
                    <button type="submit">مرحله بعد →</button>
                </form>
            </div>
            
        <?php elseif ($step === 3): ?>
            <!-- Step 3: Admin User -->
            <div class="step">
                <h2>
                    <span class="step-number">3</span>
                    ایجاد کاربر مدیر
                </h2>
                <div class="step-description">
                    <strong>📋 این مرحله چه کاری انجام می‌دهد؟</strong><br>
                    یک حساب کاربری مدیر برای شما ایجاد می‌کند که با آن می‌توانید به پنل مدیریت ربات وارد شوید. از این حساب برای مدیریت کانال‌ها، تگ‌ها و تنظیمات ربات استفاده می‌کنید.
                </div>
                <form method="POST">
                    <input type="hidden" name="action" value="step3">
                    <div class="form-group">
                        <label>نام کاربری مدیر: <span style="color: red;">*</span></label>
                        <input type="text" name="admin_username" required autofocus>
                        <small>این نام کاربری برای ورود به پنل مدیریت استفاده می‌شود.</small>
                    </div>
                    <div class="form-group">
                        <label>ایمیل مدیر (اختیاری):</label>
                        <input type="email" name="admin_email">
                        <small>در صورت نیاز می‌توانید ایمیل خود را وارد کنید.</small>
                    </div>
                    <div class="form-group">
                        <label>رمز عبور مدیر: <span style="color: red;">*</span></label>
                        <input type="password" name="admin_password" required>
                        <small>رمز عبور قوی انتخاب کنید (حداقل 8 کاراکتر توصیه می‌شود).</small>
                    </div>
                    <div class="form-group">
                        <label>تایید رمز عبور: <span style="color: red;">*</span></label>
                        <input type="password" name="admin_password_confirm" required>
                        <small>رمز عبور را دوباره وارد کنید.</small>
                    </div>
                    <button type="submit">مرحله بعد →</button>
                </form>
            </div>
            
        <?php elseif ($step === 4): ?>
            <!-- Step 4: Bot Configuration -->
            <div class="step">
                <h2>
                    <span class="step-number">4</span>
                    تنظیمات ربات
                </h2>
                <div class="step-description">
                    <strong>📋 این مرحله چه کاری انجام می‌دهد؟</strong><br>
                    توکن ربات و آدرس وب‌سایت را از شما می‌گیرد و تنظیمات نهایی را انجام می‌دهد. توکن ربات را می‌توانید از <a href="https://t.me/BotFather" target="_blank">@BotFather</a> در تلگرام دریافت کنید.
                </div>
                <form method="POST">
                    <input type="hidden" name="action" value="step4">
                    <div class="form-group">
                        <label>توکن ربات: <span style="color: red;">*</span></label>
                        <input type="text" name="bot_token" placeholder="123456789:ABCdefGHIjklMNOpqrsTUVwxyz..." required>
                        <small>
                            برای دریافت توکن:<br>
                            1. به <a href="https://t.me/BotFather" target="_blank">@BotFather</a> در تلگرام بروید<br>
                            2. دستور <code>/newbot</code> را ارسال کنید<br>
                            3. نام و username ربات را وارد کنید<br>
                            4. توکن دریافتی را اینجا قرار دهید
                        </small>
                    </div>
                    <div class="form-group">
                        <label>آدرس پایه وب‌سایت: <span style="color: red;">*</span></label>
                        <input type="text" name="base_url" value="<?= htmlspecialchars('https://' . ($_SERVER['HTTP_HOST'] ?? '')) ?>" required>
                        <small>آدرس کامل وب‌سایت شما با https:// (مثال: https://example.com)</small>
                    </div>
                    <div class="form-group">
                        <label>حالت تجزیه:</label>
                        <select name="parse_mode">
                            <option value="MarkdownV2" selected>MarkdownV2 (پیشنهادی)</option>
                            <option value="HTML">HTML</option>
                        </select>
                        <small>MarkdownV2 برای پیام‌های فارسی بهتر است.</small>
                    </div>
                    <div class="form-group">
                        <label>زبان:</label>
                        <select name="locale">
                            <option value="fa" selected>فارسی (FA)</option>
                            <option value="en">English (EN)</option>
                        </select>
                    </div>
                    <button type="submit">اتمام نصب ✅</button>
                </form>
            </div>
            
        <?php elseif ($step === 5): ?>
            <!-- Step 5: Complete -->
            <div class="step">
                <h2>
                    <span class="step-number">✓</span>
                    نصب با موفقیت انجام شد!
                </h2>
                <div class="success">
                    ✅ ربات شما با موفقیت نصب و پیکربندی شد. حالا می‌توانید از ربات استفاده کنید.
                </div>
                
                <div class="info">
                    <strong>🌐 آدرس وب‌هوک:</strong>
                    <p style="margin-top: 10px;"><code><?= htmlspecialchars($successData['webhook_url'] ?? '') ?></code></p>
                    
                    <?php if (isset($successData['webhook_status'])): ?>
                        <?php $ws = $successData['webhook_status']; ?>
                        <p style="margin-top: 15px;">
                            <strong>وضعیت تنظیم خودکار وب‌هوک:</strong><br>
                            <?php if ($ws['success'] ?? false): ?>
                                <span style="color: #28a745; font-weight: bold;">✅ وب‌هوک با موفقیت تنظیم شد!</span>
                                <div style="margin-top: 10px; padding: 10px; background: #d4edda; border-radius: 4px; border-right: 3px solid #28a745;">
                                    ربات آماده دریافت پیام‌های کانال است.
                                </div>
                            <?php else: ?>
                                <span style="color: #dc3545; font-weight: bold;">❌ خطا در تنظیم خودکار وب‌هوک</span>
                                <div style="margin-top: 10px; padding: 10px; background: #f8d7da; border-radius: 4px; border-right: 3px solid #dc3545;">
                                    <strong>خطا:</strong> <?= htmlspecialchars($ws['error'] ?? ($ws['result']['description'] ?? 'خطای ناشناخته')) ?><br>
                                    <small style="display: block; margin-top: 8px;">
                                        نگران نباشید! می‌توانید بعداً از پنل مدیریت → وضعیت سیستم → تنظیم مجدد Webhook، وب‌هوک را تنظیم کنید.
                                    </small>
                                </div>
                            <?php endif; ?>
                        </p>
                    <?php endif; ?>
                </div>
                
                <div class="warning" style="margin-top: 20px;">
                    <strong>⚠️ نکات مهم:</strong>
                    <ul style="margin-right: 25px; margin-top: 10px; line-height: 1.8;">
                        <li>ربات را به کانال خود اضافه کنید و به عنوان <strong>مدیر</strong> تعیین کنید.</li>
                        <li>از پنل مدیریت، کانال خود را اضافه کنید (Chat ID یا Username).</li>
                        <li>تگ‌ها و شناسه‌های موردنیاز را در بخش "تگ‌ها و ID" اضافه کنید.</li>
                        <li>قالب پیام خود را در بخش "قالب پیام" تنظیم کنید.</li>
                        <li>برای امنیت بیشتر، پوشه <code>/install</code> را پس از نصب حذف کنید.</li>
                    </ul>
                </div>
                
                <div style="margin-top: 30px;">
                    <a href="/admin/" style="text-decoration: none;">
                        <button style="background: #28a745;">🎯 ورود به پنل مدیریت</button>
                    </a>
                </div>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>
